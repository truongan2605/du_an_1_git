<footer>
            <div class=" text">
                <h1>Đăng ký nhận bản tin
                </h1>
                <p> Để nhận các thông tin mới từ TechStore và các chương trình khuyến mại</p>
            </div>

            <form>
                <div class="text1">
                    <input type="text" placeholder="   Nhập email vào đây">
                </div>
            </form>
        </footer>

        <section>
            <div>
                <div class="chu">
                    <h1>Về TechStore </h1>
                    <p> Trang thương mại chính thức của Dũng CT - Trực Tiếp Game. Luôn tìm kiếm những sản phẩm vì game thủ.</p>
                </div>
                <div class="chu">
                    <h1>Thông tin liên hệ</h1>
                    <p>
                        Địa Chỉ: 40 Nguyên xá - Minh Khai- Bắc Từ Liêm - Hà Nội
                        Hotline: 0346564005<br>
                        TechStore@gmail.com </p>
                </div>
                <div class="chu">
                    <h1>Tài khoản ngân hàng</h1>
                    <p>
                        Tài khoản ngân hàng<br>
                        Tìm kiếm<br>
                        Phương thức thanh toán</p>
                </div>
                <div class="chu">
                    <h1>Chính sách</h1>
                    <p>
                        Chính sách bảo mật<br>
                        Qui định bảo hành<br>
                        Chính sách đổi trả<br>
                        Điều khoản sử dụng<br>
                        Chính sách vận chuyển & kiểm hàng<br>
                        Phân định trách nhiệm của tổ chức cung ứng dịch logistics.
                    </p>
                </div>
                <div class="img">
                    <img src="">
                </div>
        </section>



    </div>

</body>

</html>